var express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    mongoose = require('mongoose'),
    taskController = require('./dataLayer/controller/dataTask-controller');

mongoose.connect('mongodb://localhost:27017/needle');

app.use(bodyParser());

app.get('/', function(req, res){
    res.sendfile(__dirname + '/public/views/index.html');
});

app.use('/js', express.static(__dirname + '/public/js'));
app.use('/css', express.static(__dirname + '/public/css'));
app.use('/resources', express.static(__dirname + '/public/resources'));

app.get('/api/taskLists', taskController.dataList);
app.post('/api/taskLists', taskController.create);
//app.delete('/api/taskLists/:id', taskController.delete);


app.listen(8000, function(){
    console.log('The connection has been established..');
});