$(document).ready(function(){
   $('[data-toggle="offcanvas"]').click(function(){
       $("#navigation").toggleClass("hidden-xs");
   });
});

$('.user-dashboard').off('.the-task', 'click').on('.the-task','click',function(){
    //alert();
});

function setActive(id){
    $(id).addClass('active');
    $(id).parent().siblings().find('button').removeClass('active');
}