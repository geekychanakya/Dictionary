app.controller('productController', ['$scope', '$resource', function($scope, $resource){
    
    var Tasklist = $resource('/api/taskLists');
    
    Tasklist.query(function(results){
       $scope.taskLists = results;
    });
    
    $scope.hideModal = function(){
            $('.fade.in').hide();
    }
    
    //$scope.filters = [];
    
    $scope.taskLists = [];
    $scope.currentObject = {};
    
    $scope.createNewTask = function(){        
        $scope.hideModal();        
        var taskList = new Tasklist();
        taskList.type =    $scope.TempObject.productsType;
        taskList.title =   $scope.TempObject.productsTitle;
        taskList.name =    $scope.TempObject.productsName;
        taskList.calorie = $scope.TempObject.productsCalorie;
        taskList.protein = $scope.TempObject.productsProtein;
        taskList.description = $scope.TempObject.productsDescription;
        taskList.$save(function(result){
            $scope.taskLists.push(result);
        });        
        $scope.TempObject={};
    }  
    
    $scope.editTask= function(item) {
	       $scope.currentObject = item; 
	};
    
    
    $scope.updateTask = function(currentObject){        
        $scope.hideModal();
//        var taskList = new Tasklist();
//        taskList.id =      $scope.currentObject._id;
//        taskList.type =    $scope.currentObject.type;
//        taskList.title =   $scope.currentObject.title;
//        taskList.name =    $scope.currentObject.name;
//        taskList.calorie = $scope.currentObject.calorie;
//        taskList.protein = $scope.currentObject.protein;
//        taskList.description = $scope.currentObject.description;
//        taskList.$save(function(result){         
//        });
        $scope.currentObject = {};
    }  
    
    $scope.deleteTask= function(item){
        $scope.hideModal();
//        $resource('/api/taskLists/:productId', {
//            productId: 'item._id'
//        });
        var index = $scope.taskLists.indexOf(item);
        $scope.taskLists.splice(index, 1);
        $scope.currentObject = {};
    }
    
}]);
