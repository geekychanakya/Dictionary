var mongoose = require('mongoose');

module.exports = mongoose.model('Product', {
    type: String,
    title: String,
    name: String,
    calorie: String,
    protein: String,
    description: String
});