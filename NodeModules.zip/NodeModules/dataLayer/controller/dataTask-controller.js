var Product = require('../models/product');

module.exports.create = function(req, res){
    var product = new Product(req.body);
    product.save(function(err, result){
        res.json(result);
    });
}

module.exports.dataList = function(req, res){
    Product.find({}, function(err, results){
        res.json(results);
    });
}

//module.exports.delete = function(req, res){
//    Product.findByIdAndRemove({productId = _id},function(err, result){
//        res.json(result);
//    });
//}